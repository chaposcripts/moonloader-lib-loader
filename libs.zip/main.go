package main

import "fmt"

const path = "./temp_libs_zip"

func main() {
	fmt.Println("Started!")
	var err error
	err = loadZip(zipURL, path+".zip")
	if err != nil {
		panic(err)
	}
	err = unzip(path+".zip", "./temp_libs_zip")
	if err != nil {
		panic(err)
	}
}
