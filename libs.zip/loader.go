package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
)

const zipURL string = ""

func loadZip(url, path string) error {
	response, err := http.Get(url)
	if err != nil {
		return err
	}
	if response.StatusCode != http.StatusOK {
		return fmt.Errorf("HTTP_STATUS_%d", response.StatusCode)
	}
	bodyBytes, err := io.ReadAll(response.Body)
	if err != nil {
		return err
	}
	err = os.WriteFile(path, bodyBytes, 0644)
	return err
}
